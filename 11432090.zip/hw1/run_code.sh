#!/bin/bash
ls
python3 frequen 450 3 browsingdata.txt
echo 'LOOK AT OUTPUT.TXT FOR MORE'
